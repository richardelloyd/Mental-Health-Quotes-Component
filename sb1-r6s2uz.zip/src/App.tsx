import React from 'react';
import QuoteCard from './components/QuoteCard';

function App() {
  return <QuoteCard />;
}

export default App;